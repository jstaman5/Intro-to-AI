Jared Staman
CS 423: Machine Learning Project

This project uses two models, Support Vector Machines(svm)
and Neural Networks(nn), to predict whether a mushroom is 
poisonous or edible. The mushroom csv file given contains 22
features besides poisonous/edible. The goal of the two models
is to best predict whether a mushroom is poisonous or edible
given the other 22 features.

How to run code:
python svm_search.py
python svm_best.py
python nn_search.py
python nn_best.py